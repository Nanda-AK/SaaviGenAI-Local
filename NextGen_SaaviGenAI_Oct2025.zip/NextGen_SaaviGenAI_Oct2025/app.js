// SaaviGen.AI Website JavaScript with Particle Network Animation and AI Chatbots

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initNavigation();
    initTestimonials();
    initContactForm();
    initScrollEffects();
    initEventRegistration();
    initBoxAnimations();
    initChatbots();
    
    // Initialize particle animation with a small delay to ensure canvas is ready
    setTimeout(() => {
        initParticleAnimation();
    }, 100);
});

// Particle Network Animation Implementation
// --- START replacement: initParticleAnimation (rope-like sine wave of dots) ---
function initParticleAnimation() {
    const canvas = document.getElementById('particleCanvas');
    if (!canvas) {
        console.warn('Particle canvas not found');
        return;
    }
    const ctx = canvas.getContext('2d');

    // Config — tweak these if you want a slightly different feel
    
const BASE = {
  cycles: 1.3,
  speed: 0.35 / 1000,
  dotSizeDesktop: 3.6,
  dotSizeMobile: 1.8,
  amplitudeDesktop: 34,
  amplitudeTablet: 24,
  amplitudeMobile: 12,
  backWaveOpacity: 0.12,
  backWaveScale: 1.25,
  highlightCore: 'rgba(223,162,255,1)',
  primaryOuter: 'rgba(155,77,255,0.65)',
  darkerOuter: 'rgba(110,46,255,0)',
  smoothing: 0.12,
  sizeVarianceMin: 0.6,
  sizeVarianceMax: 1.6,
  jitterStrength: 2.2,

  // NEW / configurable:
  verticalOffset: 0.85,        // 0.0 = top, 1.0 = bottom. 0.70 places wave lower on the hero.
  fineDotsMultiplier: 2.2,     // how many fine dots relative to main dots (increase = denser fine line)
  fineSizeTiers: [1.6, 1.2, 0.9, 0.6, 0.35], // five size multipliers (largest to smallest)
  fineOpacity: 0.65,           // opacity for fine dots core
  fineGlowScale: 3.5           // radial gradient scale for fine dots
};



    // Respect reduced-motion
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        // Draw a single static, subtle wave frame and stop
        function drawStatic() {
            resize();
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            const w = canvas.clientWidth;
            const h = canvas.clientHeight;
            const centerY = h * 0.55;
            const count = Math.max(36, Math.round(w / 20));
            for (let i = 0; i < count; i++) {
                const t = i / (count - 1);
                const x = t * w;
                const angle = t * BASE.cycles * Math.PI * 2;
                const y = centerY + Math.sin(angle) * (w < 600 ? BASE.amplitudeMobile : BASE.amplitudeTablet) * 0.6;
                const size = w < 600 ? BASE.dotSizeMobile : (BASE.dotSizeDesktop * 0.8);
                const grad = ctx.createRadialGradient(x, y, 0, x, y, size * 4);
                grad.addColorStop(0, BASE.highlightCore);
                grad.addColorStop(0.5, BASE.primaryOuter);
                grad.addColorStop(1, BASE.darkerOuter);
                ctx.globalCompositeOperation = 'lighter';
                ctx.fillStyle = grad;
                ctx.beginPath();
                ctx.arc(x, y, size, 0, Math.PI * 2);
                ctx.fill();
                ctx.globalCompositeOperation = 'source-over';
            }
        }
        // initial draw and exit
        resize();
        drawStatic();
        return;
    }

    // State
    let rafId = null;
    let phase = 0;
    let dots = [];
    let centerY = 0;
    let width = 0, height = 0;
    let devicePixelRatio = window.devicePixelRatio || 1;
    const mouse = { x: -9999, y: -9999, active: false };

    // Compute responsive params and dot list
    function computeDots() {
        const w = canvas.clientWidth;
        const count = w < 600 ? 36 : (w < 1200 ? 56 : 80);
        const arr = [];
        for (let i = 0; i < count; i++) {
            const t = i / (count - 1);
            arr.push({
                t,
                x: t * w,
                offset: (Math.random() * Math.PI * 2),
                jitter: (Math.random() * 2 - 1) * BASE.jitterStrength,
                sizeMul: BASE.sizeVarianceMin + Math.random() * (BASE.sizeVarianceMax - BASE.sizeVarianceMin),
                prevY: null
            });
        }
        dots = arr;
    }
    


	// Compute a dense, fine dot line with five size tiers decreasing
    let fineDots = [];
    function computeFineDots() {
        const w = canvas.clientWidth;
        // number of fine dots scales with main dots * multiplier
        const mainCount = (w < 600 ? 36 : (w < 1200 ? 56 : 80));
        const fineCount = Math.round(mainCount * BASE.fineDotsMultiplier);
        const arr = [];
        for (let i = 0; i < fineCount; i++) {
            const t = i / (fineCount - 1);
            // assign a tier index across the five tiers so sizes step smoothly
            const tierIndex = Math.floor(t * (BASE.fineSizeTiers.length - 1));
            // add slight spread so sizes subtly vary across dots rather than harsh buckets
            const tierMultiplier = BASE.fineSizeTiers[tierIndex] * (0.92 + Math.random() * 0.16);
            arr.push({
                t,
                x: t * w,
                tierMultiplier,
                offset: (Math.random() * Math.PI * 2),
                jitter: (Math.random() * 2 - 1) * (BASE.jitterStrength * 0.4),
                prevY: null
            });
        }
        fineDots = arr;
    }

    // Resize with DPR handling and recompute dots
    function resize() {
        const hero = document.querySelector('.hero') || document.body;
        const rect = hero.getBoundingClientRect();
        width = Math.max(0, rect.width);
        height = Math.max(0, rect.height);
        const DPR = window.devicePixelRatio || 1;
        canvas.style.width = width + 'px';
        canvas.style.height = height + 'px';
        canvas.width = Math.round(width * DPR);
        canvas.height = Math.round(height * DPR);
        // Scale drawing operations to logical CSS pixels
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
        centerY = height * (BASE.verticalOffset || 0.55);
	devicePixelRatio = DPR;
        computeDots();
	computeFineDots();
    }

    // Mouse interactions (subtle bump)
    canvas.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        mouse.x = e.clientX - rect.left;
        mouse.y = e.clientY - rect.top;
        mouse.active = true;
    });
    canvas.addEventListener('mouseleave', () => {
        mouse.active = false;
        mouse.x = -9999; mouse.y = -9999;
    });

    // Draw one wave (used for back wave and main wave)
function drawWave(opts) {
    const { scale = 1, opacity = 1, sizeMult = 1, speedMult = 1, delta = 16 } = opts;
    const w = width;
    const cycleCount = BASE.cycles;
    const ampBase = (w < 600 ? BASE.amplitudeMobile : (w < 1200 ? BASE.amplitudeTablet : BASE.amplitudeDesktop)) * scale;
    const baseSize = (w < 600 ? BASE.dotSizeMobile : BASE.dotSizeDesktop) * sizeMult;

    // damping factor for lerp: create a framerate-aware lerp amount
    const lerpFactor = 1 - Math.pow(1 - BASE.smoothing, Math.max(1, delta / 16));

    dots.forEach((d, i) => {
        const t = d.t;
        const baseAngle = t * cycleCount * Math.PI * 2;
        const ySine = Math.sin(baseAngle + phase * speedMult + d.offset);
        // compute raw target Y
        let amplitude = ampBase;
        // mouse bump (unchanged subtle behavior)
        if (mouse.active) {
            const dx = d.x - mouse.x;
            const dy = (centerY + ySine * amplitude) - mouse.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 180) {
                amplitude += (1 - (dist / 180)) * 12;
            }
        }
        const rawY = centerY + ySine * amplitude + d.jitter * Math.sin(phase * 0.001 + d.offset);
        // init prevY if absent
        if (d.prevY === null) d.prevY = rawY;
        // smooth current Y by lerping previous
        const y = d.prevY + (rawY - d.prevY) * lerpFactor;
        d.prevY = y;

        // apply per-dot size variance and subtle breathing
        const sizeVariance = d.sizeMul || 1.0;
        const breathing = 0.06 * (1 - Math.abs(ySine)); // tiny breathing effect
        const r = Math.max(0.9, baseSize * sizeVariance * (1 + breathing));

        // radial gradient for glow (reused)
        const grad = ctx.createRadialGradient(d.x, y, 0, d.x, y, r * 5);
        grad.addColorStop(0, BASE.highlightCore);
        grad.addColorStop(0.45, BASE.primaryOuter);
        grad.addColorStop(1, BASE.darkerOuter);

        ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(d.x, y, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
    });
}

function drawFineDots() {
    if (!fineDots || fineDots.length === 0) return;
    const w = width;
    const cycleCount = BASE.cycles;
    const ampBase = (w < 600 ? BASE.amplitudeMobile : (w < 1200 ? BASE.amplitudeTablet : BASE.amplitudeDesktop)) * 0.55;
    // draw faint fine dots along a very narrow band centered on centerY
    fineDots.forEach((d, i) => {
        const t = d.t;
        const baseAngle = t * cycleCount * Math.PI * 2;
        const ySine = Math.sin(baseAngle + phase * 1.0 + d.offset);
        const rawY = centerY + ySine * ampBase + d.jitter * Math.sin(phase * 0.001 + d.offset * 0.5);

        if (d.prevY === null) d.prevY = rawY;
        // use a tighter smoothing for fine dots (very silky)
        const lerpFactor = 1 - Math.pow(1 - BASE.smoothing * 1.4, 1); // simple frame-independent tweak
        const y = d.prevY + (rawY - d.prevY) * lerpFactor;
        d.prevY = y;

        // size based on tierMultiplier (these are very small)
        const baseSize = (width < 600 ? 0.8 : 1.6); // base small radius
        const r = Math.max(0.6, baseSize * d.tierMultiplier * 0.75);

        // subtle gradient glow (tiny)
        const grad = ctx.createRadialGradient(d.x, y, 0, d.x, y, r * BASE.fineGlowScale);
        grad.addColorStop(0, `rgba(223,162,255, ${BASE.fineOpacity})`);
        grad.addColorStop(0.45, `rgba(155,77,255, ${BASE.fineOpacity * 0.6})`);
        grad.addColorStop(1, 'rgba(110,46,255, 0)');

        ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(d.x, y, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
    });
}






    // Main loop

    let lastTs = null;
    function animate(ts) {
        if (!lastTs) lastTs = ts || performance.now();
        const delta = (ts || performance.now()) - lastTs;
        lastTs = ts || performance.now();

        // Update phase using delta for smooth, framerate-independent motion
        phase += BASE.speed * delta;

        // Clear canvas (crisp)
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Draw fine dense dotted line first (behind the waves)
        ctx.save();
        ctx.globalAlpha = 0.85; // slightly subdued
        drawFineDots();
        ctx.restore();

        // Draw faint back wave for depth
        ctx.save();
        ctx.globalAlpha = BASE.backWaveOpacity;
        drawWave({ scale: BASE.backWaveScale, opacity: BASE.backWaveOpacity, sizeMult: 0.86, speedMult: 0.55, delta });
        ctx.restore();

        // Draw main rope wave
        drawWave({ scale: 1, opacity: 1, sizeMult: 1.0, speedMult: 1.0, delta });

        rafId = requestAnimationFrame(animate);
    }


    // Start
    resize();
    // initial frame to avoid flicker
    requestAnimationFrame((ts) => {
        phase = 0;
        animate(ts);
    });

    // Resize handler (debounced). debounce() exists later in file, so safe to call.
    const handleResize = debounce(() => {
        resize();
    }, 120);
    window.addEventListener('resize', handleResize);

    // Clean up on page unload
    window.addEventListener('beforeunload', () => {
        if (rafId) cancelAnimationFrame(rafId);
    });

    console.log('Particle rope-wave animation initialized successfully');
}
// --- END replacement: initParticleAnimation ---





// AI Chatbots Initialization
function initChatbots() {
    initAiMiniChatbot();
    initAiAgenticChatbot();
}

// AI Mini Chatbot (Blue)
function initAiMiniChatbot() {
    const chatbotBtn = document.getElementById('aiMiniBtn');
    const chatbotPopup = document.getElementById('aiMiniPopup');
    const closeBtn = document.getElementById('aiMiniClose');
    const form = document.getElementById('aiMiniForm');
    const input = document.getElementById('aiMiniInput');
    const messages = document.getElementById('aiMiniMessages');
    const quickBtns = document.querySelectorAll('#aiMiniChatbot .quick-question-btn');
    
    // Toggle chatbot
    chatbotBtn.addEventListener('click', () => {
        chatbotPopup.classList.toggle('hidden');
        chatbotBtn.classList.toggle('hidden');
        
        // Hide the agentic chatbot button when this popup is open
        const agenticBtn = document.getElementById('aiAgenticBtn');
        if (!chatbotPopup.classList.contains('hidden')) {
            agenticBtn.style.opacity = '0.5';
            agenticBtn.style.pointerEvents = 'none';
        } else {
            agenticBtn.style.opacity = '1';
            agenticBtn.style.pointerEvents = 'auto';
        }
    });
    
    closeBtn.addEventListener('click', () => {
        chatbotPopup.classList.add('hidden');
        chatbotBtn.classList.remove('hidden');
        
        // Restore agentic chatbot button
        const agenticBtn = document.getElementById('aiAgenticBtn');
        agenticBtn.style.opacity = '1';
        agenticBtn.style.pointerEvents = 'auto';
    });
    
    // Quick question buttons
    quickBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const question = btn.getAttribute('data-question');
            sendMessage(question, messages, 'https://api.saavigen.ai/chat', 'question');
        });
    });
    
    // Form submission
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const message = input.value.trim();
        if (message) {
            sendMessage(message, messages, 'https://api.saavigen.ai/chat', 'question');
            input.value = '';
        }
    });
}

// AI Agentic Chatbot (Green)
function initAiAgenticChatbot() {
    const chatbotBtn = document.getElementById('aiAgenticBtn');
    const chatbotPopup = document.getElementById('aiAgenticPopup');
    const closeBtn = document.getElementById('aiAgenticClose');
    const form = document.getElementById('aiAgenticForm');
    const input = document.getElementById('aiAgenticInput');
    const messages = document.getElementById('aiAgenticMessages');
    const quickBtns = document.querySelectorAll('#aiAgenticChatbot .quick-question-btn');
    
    // Toggle chatbot
    chatbotBtn.addEventListener('click', () => {
        chatbotPopup.classList.toggle('hidden');
        chatbotBtn.classList.toggle('hidden');
        
        // Hide the mini chatbot button when this popup is open
        const miniBtn = document.getElementById('aiMiniBtn');
        if (!chatbotPopup.classList.contains('hidden')) {
            miniBtn.style.opacity = '0.5';
            miniBtn.style.pointerEvents = 'none';
        } else {
            miniBtn.style.opacity = '1';
            miniBtn.style.pointerEvents = 'auto';
        }
    });
    
    closeBtn.addEventListener('click', () => {
        chatbotPopup.classList.add('hidden');
        chatbotBtn.classList.remove('hidden');
        
        // Restore mini chatbot button
        const miniBtn = document.getElementById('aiMiniBtn');
        miniBtn.style.opacity = '1';
        miniBtn.style.pointerEvents = 'auto';
    });
    
    // Quick question buttons
    quickBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const question = btn.getAttribute('data-question');
            sendMessage(question, messages, 'https://api2.saavigen.ai/query', 'query');
        });
    });
    
    // Form submission
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const message = input.value.trim();
        if (message) {
            sendMessage(message, messages, 'https://api2.saavigen.ai/query', 'query');
            input.value = '';
        }
    });
}

// Send message function for both chatbots
function sendMessage(message, messagesContainer, apiEndpoint, payloadKey) {
    // Add user message
    addMessage(message, messagesContainer, 'user');
    
    // Add typing indicator
    const typingIndicator = addTypingIndicator(messagesContainer);
    
    // Prepare payload
    const payload = {};
    payload[payloadKey] = message;
    
    // Send to API
    fetch(apiEndpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        removeTypingIndicator(typingIndicator);
        
        // Handle response based on the API structure
        let botResponse = 'Thank you for your question! Our team will get back to you soon.';
        
        if (data.response) {
            botResponse = data.response;
        } else if (data.answer) {
            botResponse = data.answer;
        } else if (data.message) {
            botResponse = data.message;
        }
        
        addMessage(botResponse, messagesContainer, 'bot');
    })
    .catch(error => {
        console.error('Chatbot API Error:', error);
        removeTypingIndicator(typingIndicator);
        
        // Fallback responses
        const fallbackResponses = [
            "Thank you for your question! I'm currently experiencing high demand. Our team will get back to you soon via email.",
            "I appreciate your interest in SaaviGen.AI! For immediate assistance, please contact us at contact@saavigen.ai",
            "Thanks for reaching out! While I'm temporarily unavailable, you can explore our services above or contact our team directly."
        ];
        
        const randomResponse = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
        addMessage(randomResponse, messagesContainer, 'bot');
    });
}

// Add message to chat
function addMessage(text, container, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chatbot-message ${sender}-message`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.textContent = text;
    
    messageDiv.appendChild(contentDiv);
    container.appendChild(messageDiv);
    
    // Scroll to bottom
    container.scrollTop = container.scrollHeight;
}

// Add typing indicator
function addTypingIndicator(container) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chatbot-message bot-message typing-indicator';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.innerHTML = '<span>●</span><span>●</span><span>●</span>';
    contentDiv.style.cssText = `
        display: flex;
        gap: 4px;
        animation: typing 1.5s infinite;
    `;
    
    // Add CSS animation for typing indicator
    if (!document.querySelector('#typingAnimation')) {
        const style = document.createElement('style');
        style.id = 'typingAnimation';
        style.textContent = `
            @keyframes typing {
                0%, 60%, 100% { opacity: 1; }
                30% { opacity: 0.5; }
            }
            .typing-indicator span:nth-child(1) { animation-delay: 0s; }
            .typing-indicator span:nth-child(2) { animation-delay: 0.3s; }
            .typing-indicator span:nth-child(3) { animation-delay: 0.6s; }
        `;
        document.head.appendChild(style);
    }
    
    messageDiv.appendChild(contentDiv);
    container.appendChild(messageDiv);
    container.scrollTop = container.scrollHeight;
    
    return messageDiv;
}

// Remove typing indicator
function removeTypingIndicator(indicator) {
    if (indicator && indicator.parentNode) {
        indicator.parentNode.removeChild(indicator);
    }
}

// Navigation functionality
function initNavigation() {
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');
    const logoLinks = document.querySelectorAll('.logo-link');
    
    // Logo click functionality - navigate to home
    logoLinks.forEach(logoLink => {
        logoLink.addEventListener('click', function(e) {
            e.preventDefault();
            scrollToHome();
        });
    });
    
    // Mobile menu toggle
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            navToggle.classList.toggle('active');
        });
    }
    
    // Close mobile menu when clicking on links
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (navMenu) {
                navMenu.classList.remove('active');
            }
            if (navToggle) {
                navToggle.classList.remove('active');
            }
        });
    });
    
    // Smooth scrolling for navigation links (only for same-page links)
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href && href.startsWith('#')) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const targetSection = document.querySelector(href);
                
                if (targetSection) {
                    const headerHeight = document.querySelector('.header').offsetHeight;
                    const targetPosition = targetSection.offsetTop - headerHeight - 20;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        }
    });
    
    // Header scroll effect
    let lastScrollY = window.scrollY;
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.header');
        const currentScrollY = window.scrollY;
        
        if (currentScrollY > 100) {
            header.style.background = 'rgba(17, 17, 17, 0.95)';
            header.style.backdropFilter = 'blur(10px)';
        } else {
            header.style.background = 'var(--color-surface)';
            header.style.backdropFilter = 'none';
        }
        
        lastScrollY = currentScrollY;
    });
}

// Scroll to home functionality
function scrollToHome() {
    const homeSection = document.getElementById('home');
    if (homeSection) {
        const headerHeight = document.querySelector('.header').offsetHeight;
        const targetPosition = homeSection.offsetTop - headerHeight;
        
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
    }
}

// Show Product Section with Animation
function showProductSection() {
    const productsSection = document.getElementById('products');
    if (productsSection) {
        // Reset and trigger animations
        resetBoxAnimations('productsGrid');
        triggerBoxAnimations('productsGrid');
        
        // Scroll to section
        const headerHeight = document.querySelector('.header').offsetHeight;
        const targetPosition = productsSection.offsetTop - headerHeight - 20;
        
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
    }
}

// Show Service Section with Animation
function showServiceSection() {
    const servicesSection = document.getElementById('services');
    if (servicesSection) {
        // Reset and trigger animations
        resetBoxAnimations('servicesGrid');
        triggerBoxAnimations('servicesGrid');
        
        // Scroll to section
        const headerHeight = document.querySelector('.header').offsetHeight;
        const targetPosition = servicesSection.offsetTop - headerHeight - 20;
        
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
    }
}

// Box Animation System
function initBoxAnimations() {
    // Set up product and service navigation links
    const productLinks = document.querySelectorAll('[onclick="showProductSection()"]');
    const serviceLinks = document.querySelectorAll('[onclick="showServiceSection()"]');
    
    productLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            showProductSection();
        });
    });
    
    serviceLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            showServiceSection();
        });
    });
}

// Reset box animations
function resetBoxAnimations(gridId) {
    const grid = document.getElementById(gridId);
    if (!grid) return;
    
    const boxes = grid.querySelectorAll('.animate-box');
    boxes.forEach(box => {
        // Remove all animation classes
        box.classList.remove('slide-in-1', 'slide-in-2', 'slide-in-3', 'slide-in-4');
        // Reset opacity and transform
        box.style.opacity = '0';
        box.style.transform = 'translateX(-50px)';
    });
}

// Trigger box animations
function triggerBoxAnimations(gridId) {
    const grid = document.getElementById(gridId);
    if (!grid) return;
    
    const boxes = grid.querySelectorAll('.animate-box');
    
    // Add a small delay to ensure reset is complete
    setTimeout(() => {
        boxes.forEach((box, index) => {
            const delay = (index * 200) + 100; // Stagger animations
            
            setTimeout(() => {
                box.classList.add(`slide-in-${(index % 4) + 1}`);
            }, delay);
        });
    }, 50);
}

// Testimonials carousel functionality
function initTestimonials() {
    const testimonialCards = document.querySelectorAll('.testimonial-card');
    const testimonialBtns = document.querySelectorAll('.testimonial-btn');
    let currentTestimonial = 0;
    let testimonialInterval;
    
    if (testimonialCards.length === 0) return;
    
    function showTestimonial(index) {
        // Hide all testimonials
        testimonialCards.forEach(card => {
            card.classList.remove('active');
        });
        
        // Remove active state from all buttons
        testimonialBtns.forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Show selected testimonial
        if (testimonialCards[index]) {
            testimonialCards[index].classList.add('active');
        }
        
        if (testimonialBtns[index]) {
            testimonialBtns[index].classList.add('active');
        }
        
        currentTestimonial = index;
    }
    
    function nextTestimonial() {
        const nextIndex = (currentTestimonial + 1) % testimonialCards.length;
        showTestimonial(nextIndex);
    }
    
    function startTestimonialCarousel() {
        testimonialInterval = setInterval(nextTestimonial, 5000);
    }
    
    function stopTestimonialCarousel() {
        if (testimonialInterval) {
            clearInterval(testimonialInterval);
        }
    }
    
    // Add click handlers to testimonial buttons
    testimonialBtns.forEach((btn, index) => {
        btn.addEventListener('click', function() {
            stopTestimonialCarousel();
            showTestimonial(index);
            startTestimonialCarousel();
        });
    });
    
    // Start the carousel
    showTestimonial(0);
    startTestimonialCarousel();
    
    // Pause on hover
    const testimonialContainer = document.querySelector('.testimonials-container');
    if (testimonialContainer) {
        testimonialContainer.addEventListener('mouseenter', stopTestimonialCarousel);
        testimonialContainer.addEventListener('mouseleave', startTestimonialCarousel);
    }
}

// Contact form functionality
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(contactForm);
            const formObj = Object.fromEntries(formData);
            
            // Validate form
            if (validateContactForm(formObj)) {
                submitContactForm(formObj);
            }
        });
        
        // Real-time validation
        const formInputs = contactForm.querySelectorAll('input, select, textarea');
        formInputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                clearFieldError(this);
            });
        });
    }
}

function validateContactForm(formData) {
    let isValid = true;
    
    // Validate name
    if (!formData.name || formData.name.trim().length < 2) {
        showFieldError('name', 'Please enter a valid name');
        isValid = false;
    }
    
    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email || !emailRegex.test(formData.email)) {
        showFieldError('email', 'Please enter a valid email address');
        isValid = false;
    }
    
    // Validate message
    if (!formData.message || formData.message.trim().length < 10) {
        showFieldError('message', 'Please enter a message with at least 10 characters');
        isValid = false;
    }
    
    return isValid;
}

function validateField(field) {
    const value = field.value.trim();
    const fieldName = field.name;
    
    clearFieldError(field);
    
    switch (fieldName) {
        case 'name':
            if (!value || value.length < 2) {
                showFieldError(fieldName, 'Please enter a valid name');
                return false;
            }
            break;
        case 'email':
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!value || !emailRegex.test(value)) {
                showFieldError(fieldName, 'Please enter a valid email address');
                return false;
            }
            break;
        case 'message':
            if (!value || value.length < 10) {
                showFieldError(fieldName, 'Please enter a message with at least 10 characters');
                return false;
            }
            break;
    }
    
    return true;
}

function showFieldError(fieldName, message) {
    const field = document.querySelector(`[name="${fieldName}"]`);
    if (field) {
        field.style.borderColor = '#ff5459';
        
        // Remove existing error message
        const existingError = field.parentNode.querySelector('.field-error');
        if (existingError) {
            existingError.remove();
        }
        
        // Add new error message
        const errorElement = document.createElement('div');
        errorElement.className = 'field-error';
        errorElement.style.color = '#ff5459';
        errorElement.style.fontSize = 'var(--font-size-sm)';
        errorElement.style.marginTop = 'var(--space-4)';
        errorElement.textContent = message;
        
        field.parentNode.appendChild(errorElement);
    }
}

function clearFieldError(field) {
    field.style.borderColor = '';
    const errorElement = field.parentNode.querySelector('.field-error');
    if (errorElement) {
        errorElement.remove();
    }
}

function submitContactForm(formData) {
    const submitBtn = document.querySelector('.contact-form button[type="submit"]');
    
    if (submitBtn) {
        // Show loading state
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Sending Message';
        
        // Simulate form submission
        setTimeout(() => {
            // Show success message
            showFormSuccess();
            
            // Reset form
            document.getElementById('contactForm').reset();
            
            // Reset button
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Send Message';
        }, 2000);
    }
    
    // In a real application, you would send the data to your backend
    console.log('Form submitted:', formData);
}

function showFormSuccess() {
    const form = document.getElementById('contactForm');
    
    // Create success message
    const successMessage = document.createElement('div');
    successMessage.className = 'form-success';
    successMessage.style.cssText = `
        background-color: rgba(0, 255, 198, 0.1);
        border: 1px solid rgba(0, 255, 198, 0.3);
        color: var(--color-accent);
        padding: var(--space-16);
        border-radius: var(--radius-base);
        margin-bottom: var(--space-16);
        text-align: center;
        font-weight: var(--font-weight-medium);
    `;
    successMessage.textContent = 'Thank you! Your message has been sent successfully. We will get back to you soon.';
    
    // Insert at the top of the form
    form.insertBefore(successMessage, form.firstChild);
    
    // Remove after 5 seconds
    setTimeout(() => {
        if (successMessage.parentNode) {
            successMessage.remove();
        }
    }, 5000);
}

// Event registration functionality
function initEventRegistration() {
    const registerBtns = document.querySelectorAll('.event-card .btn');
    
    registerBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const eventCard = this.closest('.event-card');
            const eventTitle = eventCard.querySelector('.event-title').textContent;
            
            // Show registration modal
            showEventRegistration(eventTitle);
        });
    });
}

function showEventRegistration(eventTitle) {
    // Create a simple modal for event registration
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 2000;
        animation: fadeIn 0.3s ease-out;
    `;
    
    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background-color: var(--color-surface);
        border-radius: var(--radius-lg);
        padding: var(--space-32);
        max-width: 500px;
        width: 90%;
        max-height: 90vh;
        overflow-y: auto;
        position: relative;
        animation: slideUp 0.3s ease-out;
        border: 1px solid var(--color-card-border);
    `;
    
    modalContent.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-20);">
            <h3 style="color: var(--color-accent); margin: 0;">Register for Event</h3>
            <button class="modal-close" style="background: none; border: none; font-size: var(--font-size-xl); cursor: pointer; color: var(--color-text-secondary);">&times;</button>
        </div>
        <p style="color: var(--color-text-secondary); margin-bottom: var(--space-20);">
            You're registering for: <strong style="color: var(--color-accent);">${eventTitle}</strong>
        </p>
        <form class="event-registration-form">
            <div class="form-group">
                <label class="form-label" style="display: block; margin-bottom: var(--space-8); color: var(--color-text);">Full Name</label>
                <input type="text" class="form-control" required style="
                    width: 100%;
                    padding: var(--space-12);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-base);
                    background-color: var(--color-background);
                    color: var(--color-text);
                ">
            </div>
            <div class="form-group">
                <label class="form-label" style="display: block; margin-bottom: var(--space-8); color: var(--color-text);">Email Address</label>
                <input type="email" class="form-control" required style="
                    width: 100%;
                    padding: var(--space-12);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-base);
                    background-color: var(--color-background);
                    color: var(--color-text);
                ">
            </div>
            <div class="form-group">
                <label class="form-label" style="display: block; margin-bottom: var(--space-8); color: var(--color-text);">Company (Optional)</label>
                <input type="text" class="form-control" style="
                    width: 100%;
                    padding: var(--space-12);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-base);
                    background-color: var(--color-background);
                    color: var(--color-text);
                ">
            </div>
            <div class="form-group">
                <label class="form-label" style="display: block; margin-bottom: var(--space-8); color: var(--color-text);">Questions or Comments</label>
                <textarea class="form-control" rows="3" style="
                    width: 100%;
                    padding: var(--space-12);
                    border: 1px solid var(--color-border);
                    border-radius: var(--radius-base);
                    background-color: var(--color-background);
                    color: var(--color-text);
                    font-family: var(--font-family-base);
                "></textarea>
            </div>
            <button type="submit" class="btn btn--primary btn--full-width" style="
                background-color: var(--color-accent);
                color: var(--color-btn-primary-text);
                border: none;
                padding: var(--space-12) var(--space-24);
                border-radius: var(--radius-base);
                font-weight: var(--font-weight-medium);
                cursor: pointer;
                width: 100%;
            ">Register Now</button>
        </form>
    `;
    
    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    
    // Add event listeners
    const closeBtn = modal.querySelector('.modal-close');
    const form = modal.querySelector('.event-registration-form');
    
    closeBtn.addEventListener('click', () => {
        closeModal(modal);
    });
    
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal(modal);
        }
    });
    
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Show success message
        const successMsg = document.createElement('div');
        successMsg.style.cssText = `
            background-color: rgba(0, 255, 198, 0.1);
            border: 1px solid rgba(0, 255, 198, 0.3);
            color: var(--color-accent);
            padding: var(--space-16);
            border-radius: var(--radius-base);
            text-align: center;
            margin-bottom: var(--space-16);
        `;
        successMsg.textContent = 'Registration successful! You will receive a confirmation email shortly.';
        
        form.insertBefore(successMsg, form.firstChild);
        
        setTimeout(() => {
            closeModal(modal);
        }, 2000);
    });
    
    // Add CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
}

function closeModal(modal) {
    modal.style.animation = 'fadeOut 0.3s ease-out forwards';
    
    setTimeout(() => {
        if (modal.parentNode) {
            modal.remove();
        }
    }, 300);
    
    // Add fadeOut animation if not already defined
    if (!document.querySelector('#fadeOutAnimation')) {
        const style = document.createElement('style');
        style.id = 'fadeOutAnimation';
        style.textContent = `
            @keyframes fadeOut {
                from { opacity: 1; }
                to { opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
}

// Scroll effects and animations
function initScrollEffects() {
    // Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animateElements = document.querySelectorAll(
        '.service-card, .testimonial-card, .event-card, .hero-card, .founder-card, .product-preview-card'
    );
    
    animateElements.forEach(element => {
        observer.observe(element);
    });
}

// CTA button functionality
document.addEventListener('click', function(e) {
    if (e.target.matches('.nav-cta') || e.target.matches('.hero-actions .btn--primary')) {
        e.preventDefault();
        scrollToContact();
    }
    
    if (e.target.matches('.hero-actions .btn--outline')) {
        e.preventDefault();
        showServiceSection();
    }
});

function scrollToContact() {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
        const headerHeight = document.querySelector('.header').offsetHeight;
        const targetPosition = contactSection.offsetTop - headerHeight - 20;
        
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
    }
}

// Handle escape key for modals and chatbots
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const modal = document.querySelector('.modal');
        if (modal) {
            closeModal(modal);
        }
        
        // Close chatbot popups
        const miniPopup = document.getElementById('aiMiniPopup');
        const agenticPopup = document.getElementById('aiAgenticPopup');
        
        if (miniPopup && !miniPopup.classList.contains('hidden')) {
            document.getElementById('aiMiniClose').click();
        }
        
        if (agenticPopup && !agenticPopup.classList.contains('hidden')) {
            document.getElementById('aiAgenticClose').click();
        }
    }
});

// Utility function for debouncing
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Add resize handler for responsive adjustments
window.addEventListener('resize', debounce(function() {
    // Close mobile menu on resize to desktop
    if (window.innerWidth > 768) {
        const navMenu = document.getElementById('navMenu');
        const navToggle = document.getElementById('navToggle');
        
        if (navMenu && navToggle) {
            navMenu.classList.remove('active');
            navToggle.classList.remove('active');
        }
    }
}, 250));







// ===== Events image modal helpers =====
function openImageModal(imgSrc, caption) {
  const modal = document.getElementById('eventImageModal');
  const modalImg = document.getElementById('eventModalImg');
  const modalCaption = document.getElementById('eventModalCaption');

  if (!modal || !modalImg) return;
  modalImg.src = imgSrc;
  modalImg.alt = caption || '';
  modalCaption.textContent = caption || '';
  modal.setAttribute('aria-hidden','false');
  // prevent background scroll
  document.documentElement.style.overflow = 'hidden';
}

function closeImageModal(evt) {
  // allow clicking on the overlay or close button to close
  if (evt) evt.stopPropagation();
  const modal = document.getElementById('eventImageModal');
  if (!modal) return;
  modal.setAttribute('aria-hidden','true');
  const modalImg = document.getElementById('eventModalImg');
  if (modalImg) modalImg.src = '';
  document.documentElement.style.overflow = '';
}

